from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.environ.get('BLOOM_DB') or os.path.join(BASE_DIR, 'bloom.db')
SECRET_KEY = os.environ.get('BLOOM_SECRET') or 'change-this-secret-key'

app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['DATABASE'] = DATABASE

# ---------- Database helpers ----------
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(app.config['DATABASE'])
        db.row_factory = sqlite3.Row
    return db

def query_db(query, args=(), one=False, commit=False):
    cur = get_db().execute(query, args)
    if commit:
        get_db().commit()
        cur.close()
        return None
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# ---------- Simple Chatbot logic ----------
BOT_RESPONSES = {
    'happy': "That's wonderful! Keep doing what makes you happy. 😊",
    'sad': "I'm sorry you're feeling sad. It's okay to take small steps — breathe, rest, and try something gentle you enjoy.",
    'anxious': "Anxiety can be tough. Try grounding: name 5 things you can see, 4 you can touch, 3 you can hear.",
    'angry': "Anger is valid. Try stepping away, counting to ten, and breathe deeply. When ready, jot down what helped.",
    'demotivated': "Small wins matter. Pick one tiny task (5–10 minutes) and celebrate finishing it.",
    'worthless': "You matter. If you can, reach out to a friend or counselor. You're not alone — one step at a time."
}

def bot_reply(mood):
    return BOT_RESPONSES.get(mood.lower(), "Thanks for sharing. Remember it's okay to feel — take one small step today.")

# ---------- Authentication ----------
def create_user(username, password, is_admin=0):
    pw_hash = generate_password_hash(password)
    query_db('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)',
             (username, pw_hash, is_admin), commit=True)

def get_user_by_username(username):
    return query_db('SELECT * FROM users WHERE username = ?', (username,), one=True)

# ---------- Routes ----------
@app.route('/')
def index():
    user = None
    if 'user_id' in session:
        user = query_db('SELECT id, username, is_admin FROM users WHERE id = ?', (session['user_id'],), one=True)
    return render_template('index.html', user=user)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        if not username or not password:
            flash("Provide both username and password", 'danger')
            return redirect(url_for('register'))
        if get_user_by_username(username):
            flash("Username already exists", 'warning')
            return redirect(url_for('register'))
        create_user(username, password, is_admin=0)
        flash("Account created. Please log in.", 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        user = get_user_by_username(username)
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['is_admin'] = bool(user['is_admin'])
            flash("Logged in successfully", 'success')
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials", 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out", 'info')
    return redirect(url_for('index'))

@app.route('/dashboard', methods=['GET','POST'])
def dashboard():
    if 'user_id' not in session:
        flash("Please log in to access dashboard", 'warning')
        return redirect(url_for('login'))
    if request.method == 'POST':
        mood = request.form.get('mood')
        note = request.form.get('note','').strip()
        ts = datetime.utcnow().isoformat()
        query_db('INSERT INTO moods (user_id, mood, note, timestamp) VALUES (?, ?, ?, ?)',
                 (session['user_id'], mood, note, ts), commit=True)
        reply = bot_reply(mood)
        return render_template('dashboard.html', reply=reply, selected_mood=mood)
    # load moods
    moods = query_db('SELECT mood, note, timestamp FROM moods WHERE user_id = ? ORDER BY timestamp DESC LIMIT 30',
                     (session['user_id'],))
    return render_template('dashboard.html', moods=moods)

@app.route('/admin')
def admin():
    if not session.get('is_admin'):
        flash("Admin access required", 'danger')
        return redirect(url_for('index'))
    users = query_db('SELECT id, username, is_admin FROM users')
    recent = query_db('SELECT m.id, u.username, m.mood, m.note, m.timestamp FROM moods m JOIN users u ON u.id = m.user_id ORDER BY m.timestamp DESC LIMIT 100')
    return render_template('admin.html', users=users, recent=recent)

# Simple health route
@app.route('/health')
def health():
    return {'status': 'ok'}

if __name__ == '__main__':
    # Create DB if not exists
    if not os.path.exists(app.config['DATABASE']):
        with sqlite3.connect(app.config['DATABASE']) as c:
            cur = c.cursor()
            cur.execute(\"\"\"CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                is_admin INTEGER DEFAULT 0
            )\"\"\")
            cur.execute(\"\"\"CREATE TABLE moods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                mood TEXT,
                note TEXT,
                timestamp TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )\"\"\")
            # create an admin user: username=admin password=admin123 (please change in production)
            from werkzeug.security import generate_password_hash
            cur.execute('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)',
                        ('admin', generate_password_hash('admin123'), 1))
            c.commit()
    app.run(host='0.0.0.0', port=5000, debug=True)
