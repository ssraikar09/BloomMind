# BloomMind - Student Emotional Wellness Platform

This is a minimal, working Flask project for the BloomMind synopsis you provided.
It includes:
- User registration & login (hashed passwords)
- Mood submission and basic chatbot replies
- Mood history tracking
- Simple admin dashboard listing users and recent mood entries
- Default DB: SQLite (bloom.db). Optional: configure MySQL via environment variables and schema.

## Quick start (Linux / macOS / WSL)
1. Install Python 3.10+.
2. Clone or unzip the project.
3. Create and activate venv:
   ```bash
   python -m venv venv
   source venv/bin/activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run app:
   ```bash
   python app.py
   ```
6. Open `http://localhost:5000` in your browser.

## Deployment notes
- This project uses SQLite by default for simplicity. For production, use MySQL/Postgres and set `BLOOM_DB` env var or configure in a WSGI server.
- Set `BLOOM_SECRET` environment variable to a secure random key.
- Use a production WSGI server (gunicorn/uvicorn) and a proper reverse proxy (nginx) when deploying publicly.
- Change the default admin password after first run (admin/admin123).

## Files
- `app.py` — main Flask app
- `templates/` — HTML templates
- `static/` — CSS and assets
- `bloom.db` — generated on first run (if not provided)
- `schema.sql` — SQL schema for MySQL users

## Optional: MySQL
A sample `schema.sql` is included. If you want to use MySQL:
- Create a database and user.
- Set `BLOOM_DB` to the DSN or path you will use, or modify `app.py` to connect to MySQL with `pymysql` or `mysql-connector-python`.

