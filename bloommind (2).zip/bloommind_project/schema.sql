-- MySQL sample schema for BloomMind
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  is_admin TINYINT DEFAULT 0
);

CREATE TABLE moods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  mood VARCHAR(50),
  note TEXT,
  timestamp DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
