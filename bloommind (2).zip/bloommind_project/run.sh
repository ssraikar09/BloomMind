#!/bin/bash
# Simple run script for local testing
python app.py
